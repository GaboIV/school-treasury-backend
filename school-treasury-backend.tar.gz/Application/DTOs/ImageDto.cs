namespace Application.DTOs
{
    public class ImageDto : BaseDto
    {
        public required string Url { get; set; }
    }
}