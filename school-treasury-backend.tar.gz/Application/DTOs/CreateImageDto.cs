namespace Application.DTOs
{
    public class CreateImageDto
    {

    }
}
