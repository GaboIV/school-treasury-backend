namespace Application.DTOs
{
    public class CollectionTypeDto : BaseDto
    {
        public string? Name { get; set; }
    }
}