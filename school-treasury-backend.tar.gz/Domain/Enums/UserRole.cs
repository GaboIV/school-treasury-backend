namespace Domain.Enums
{
    public enum UserRole
    {
        Administrator,
        Representative,
        Professor
    }
} 